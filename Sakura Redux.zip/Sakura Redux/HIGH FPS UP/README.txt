Соблюдайте все шаги работы что бы установить всё правильно и без проблем.

1 Step. Вам нужно перенести файлы по данному пути который указан ниже:
Пример: C:\Users\ressko\AppData\Local\Roblox\Versions\version-номер вашей версии\

2 Step. Просто переносите файлы по данному пути который указан ниже:
Пример: C:\Users\ressko\AppData\Local\Roblox\



                                                                                                                                                                creator: q6izz ( Schizzov )
                                                                                                                                                                ds: q6izz
                                                                                                                                                                tg: q6izz